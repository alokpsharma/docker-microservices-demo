export interface Address {    
        id: number;
        apartmentName: string;
        streetName: string;
        city: string;
        state: string;
        pinCode: number;
    
}
