import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-primary-category-landing',
  templateUrl: './primary-category-landing.component.html',
  styleUrls: ['./primary-category-landing.component.css']
})
export class PrimaryCategoryLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
