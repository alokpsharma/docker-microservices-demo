import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-secondary-category-landing',
  templateUrl: './secondary-category-landing.component.html',
  styleUrls: ['./secondary-category-landing.component.css']
})
export class SecondaryCategoryLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
