import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tertiary-category-landing',
  templateUrl: './tertiary-category-landing.component.html',
  styleUrls: ['./tertiary-category-landing.component.css']
})
export class TertiaryCategoryLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
