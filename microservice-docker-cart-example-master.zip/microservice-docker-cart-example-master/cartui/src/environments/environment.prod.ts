export const environment = {
  production: true,
  customersURL: '/customer-service/customer',
  productsURL:'/inventory-service/inventory',
  categoryURL:'/inventory-service/category/primary',
  fullCategoryURL:'/inventory-service/category/secondary'
};
